# sarif4k
Kotlin data bindings for the Static Analysis Results Interchange Format (SARIF)
